// What could this be?
export default function IdentityView(props: any){
    
}